import SwiftUI
import MapKit
import CoreLocation

// Define a struct for our search results that is Identifiable
struct PointOfInterest: Identifiable, Equatable { // <--- Add Equatable here
    let id = UUID() // Unique identifier for each location
    let name: String
    let placemark: MKPlacemark
    var distance: CLLocationDistance? // To store distance from user, if calculated
    
    // Implement the Equatable conformance
    // We'll compare name and coordinate for simplicity
    static func == (lhs: PointOfInterest, rhs: PointOfInterest) -> Bool {
        lhs.id == rhs.id && // Compare by ID first (most robust)
        lhs.name == rhs.name &&
        lhs.placemark.coordinate.latitude == rhs.placemark.coordinate.latitude &&
        lhs.placemark.coordinate.longitude == rhs.placemark.coordinate.longitude
        // You could also compare more properties of placemark if needed,
        // but coordinate and name are usually sufficient for identity.
    }
}

// ... (rest of your LocationManager class remains the same) ...

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var userLocation: CLLocation?
    @Published var authorizationStatus: CLAuthorizationStatus?
    
    private let locationManager = CLLocationManager()
    
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    func requestLocationAuthorization() {
        if locationManager.authorizationStatus == .notDetermined {
            locationManager.requestWhenInUseAuthorization()
        } else if locationManager.authorizationStatus == .authorizedWhenInUse ||
                    locationManager.authorizationStatus == .authorizedAlways {
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        authorizationStatus = manager.authorizationStatus
        switch manager.authorizationStatus {
        case .authorizedWhenInUse, .authorizedAlways:
            manager.startUpdatingLocation()
        case .denied, .restricted:
            print("Location access denied or restricted.")
        case .notDetermined:
            break
        @unknown default:
            break
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        userLocation = location
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location manager failed with error: \(error.localizedDescription)")
    }
}


struct PharmacyFinderView: View {
    @StateObject private var locationManager = LocationManager()
    @State private var position: MapCameraPosition = .automatic
    @State private var searchText = "pharmacy"
    @State private var searchResults: [PointOfInterest] = []
    @State private var selectedPlace: PointOfInterest? // This is now Equatable due to PointOfInterest
    
    var body: some View {
        ZStack(alignment: .top) {
            Map(position: $position) {
                UserAnnotation()
                
                ForEach(searchResults) { poi in
                    Marker(poi.name, coordinate: poi.placemark.coordinate)
                        .tint(.red)
                }
            }
            .mapControls {
                MapUserLocationButton()
                MapCompass()
                MapScaleView()
            }
            .edgesIgnoringSafeArea(.all)
            .onAppear {
                locationManager.requestLocationAuthorization()
            }
            .onChange(of: locationManager.userLocation) { oldLocation, newLocation in
                if let location = newLocation {
                    position = .region(MKCoordinateRegion(
                        center: location.coordinate,
                        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
                    ))
                    performSearch()
                }
            }
            .onChange(of: selectedPlace) { oldPlace, newPlace in // This line now works!
                if let place = newPlace {
                    position = .region(MKCoordinateRegion(
                        center: place.placemark.coordinate,
                        span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005)
                    ))
                }
            }
            
            // Search Bar and Search Button (rest of your UI code)
            VStack {
                HStack {
                    TextField("Search for pharmacies, hospitals, etc.", text: $searchText)
                        .padding(8)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                        .padding(.horizontal)
                    
                    Button("Search") {
                        performSearch()
                    }
                    .padding(.trailing)
                }
                .padding(.top, 5)
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 15) {
                        ForEach(searchResults) { place in
                            PlaceCard(place: place)
                                .frame(width: 280)
                                .onTapGesture {
                                    selectedPlace = place
                                }
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 10)
                }
                .frame(maxHeight: 180)
            }
            .background(.ultraThinMaterial)
            .cornerRadius(15)
            .padding(.top, 10)
            .padding(.horizontal)
        }
        .navigationTitle("Find Nearby")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    private func performSearch() {
        guard let userLocation = locationManager.userLocation else {
            print("User location not available for search.")
            return
        }
        
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = searchText
        request.region = MKCoordinateRegion(center: userLocation.coordinate,
                                            span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
        
        let search = MKLocalSearch(request: request)
        search.start { response, error in
            guard let response = response, error == nil else {
                print("Search error: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            self.searchResults = response.mapItems.map { item in
                let distance = userLocation.distance(from: item.placemark.location!)
                return PointOfInterest(name: item.name ?? "Unknown", placemark: item.placemark, distance: distance)
            }.sorted { ($0.distance ?? 0) < ($1.distance ?? 0) }
        }
    }
}

struct PlaceCard: View {
    let place: PointOfInterest
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(place.name)
                .font(.headline)
                .lineLimit(1)
            Text(place.placemark.title ?? "")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .lineLimit(1)
            
            if let distance = place.distance {
                Text(String(format: "%.1f miles", distance / 1609.34))
                    .font(.footnote)
                    .foregroundColor(.gray)
            }
        }
        .padding()
        .background(.background)
        .cornerRadius(10)
        .shadow(radius: 3)
    }
}

struct PharmacyFinderView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            PharmacyFinderView()
        }
    }
}
