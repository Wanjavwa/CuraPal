import SwiftUI
// instead using strings or ids enum helps with defining possible navigation destination
enum Route: Hashable {
    case fourthView(username: String)
}

struct SecondView: View {
    @State private var name: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var path: [Route] = []
    
    var body: some View {
        NavigationStack(path: $path) {
            ZStack{
                LinearGradient(gradient: Gradient(colors: [Color.cyan.opacity(0.9), Color.white]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                .ignoresSafeArea()
                
                VStack(spacing: 25) {
                    
                    // Logo
                    Image("Image Asset 1") 
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 100)
                    
                    // Title
                    VStack(spacing: 5) {
                        Text("Create an account")
                            .font(.title2)
                            .bold()
                        Text("Enter your info to sign up for this app")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    
                    // Name Field
                    TextField("Full Name", text: $name)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                        .autocapitalization(.words)
                    
                    // Email Field
                    TextField("email@domain.com", text: $email)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                    
                    // Password Field
                    SecureField("Password", text: $password)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                    
                    // Continue Button
                    Button(action: {
                        path.append(.fourthView(username: name))
                    }) {
                        Text("Continue")
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.black)
                            .cornerRadius(10)
                    }
                    
                    // OR Divider
                    HStack {
                        Rectangle()
                            .frame(height: 1)
                            .foregroundColor(.gray.opacity(0.4))
                        Text("OR")
                            .foregroundColor(.gray)
                        Rectangle()
                            .frame(height: 1)
                            .foregroundColor(.gray.opacity(0.4))
                    }
                    .padding(.vertical, 5)
                    
                    // Social Buttons
                    VStack(spacing: 12) {
                        SocialButton(label: "Continue with Google", icon: "globe")
                        SocialButton(label: "Continue with Apple", icon: "applelogo")
                        SocialButton(label: "Continue with Phone", icon: "phone.fill")
                    }
                    
                    // Terms Note
                    Text("By clicking continue, you agree to our Terms of Service and Privacy Policy")
                        .font(.footnote)
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                    
                    Spacer()
                }
                .padding()
                .navigationDestination(for: Route.self) { route in
                    switch route {
                    case .fourthView(let username):
                        FourthView(username: username)
                    }
                }
            }
        }
    }
    
    // 🔘 Social Button View
    struct SocialButton: View {
        var label: String
        var icon: String
        
        var body: some View {
            HStack {
                Image(systemName: icon)
                Text(label)
            }
            .foregroundColor(.black)
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color(.systemGray5))
            .cornerRadius(10)
        }
    }
}


    
    
    

