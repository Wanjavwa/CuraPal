import SwiftUI

// Represents a single message in the chat
struct Message: Identifiable {
    let id = UUID()
    let text: String
    let isUser: Bool // True if the message is from the user, false if from the AI
    let showProfilePic: Bool // Indicates if a profile picture should be shown next to the message
}

struct AIAssistantView: View {
    @State private var messages: [Message] = [
        Message(text: "Hi Shameeka 😊 Just checking in—how are you feeling today?", isUser: false, showProfilePic: true),
        Message(text: "I’m okay… just a bit tired and feeling under the weather", isUser: true, showProfilePic: true),
        Message(text: "Thanks for sharing. Did you remember to take your calming pill (Omega 3) after lunch?", isUser: false, showProfilePic: true),
        Message(text: "Oh I forgot about that. I don’t know where I kept it", isUser: true, showProfilePic: true),
        Message(text: "Okay, let’s find it together, do see a case on your room drawer? the blue little pill inside is what to take", isUser: false, showProfilePic: true),
        Message(text: "Yes, I see the case and the pill. I have taken it with some water", isUser: true, showProfilePic: true),
        Message(text: "Well done! 😌 Should I let your daughter, Sarah know?", isUser: false, showProfilePic: true),
        Message(text: "Yes, thanks", isUser: true, showProfilePic: true),
        Message(text: "Done. You’re welcome!", isUser: false, showProfilePic: true)
    ]
    
    @State private var newMessage: String = ""
    @FocusState private var isInputActive: Bool // To dismiss keyboard if needed
    
    var body: some View {
        VStack(spacing: 0) {
            // Top Bar
            VStack {
                HStack {
                    Spacer() // Pushes AI Care Assistant to center
                    
                    VStack(spacing: 2) {
                        Text("AI Care Assistant")
                            .font(.headline)
                            .fontWeight(.bold)
                        Text("Active")
                            .font(.caption)
                            .foregroundColor(.green)
                    }
                    
                    Spacer()
                    
                    Image(systemName: "ellipsis")
                        .font(.headline)
                        .rotationEffect(.degrees(90))
                        .foregroundColor(.gray)
                }
                .padding(.horizontal)
                .padding(.top, 8) // Adjust top padding for status bar
                
                Divider()
                    .padding(.top, 8) // Add some space below the top bar
            }
            .background(Color.white)
            
            // Message List
            ScrollViewReader { scrollViewProxy in // Added ScrollViewReader
                ScrollView {
                    VStack(spacing: 15) { // Spacing between message bubbles
                        
                        Text("Jun 13, 2025, 4:00 PM")
                            .font(.caption2)
                            .foregroundColor(.gray)
                            .padding(.vertical, 10)
                        
                        ForEach(messages) { message in
                            MessageBubble(message: message)
                                .id(message.id) // Assign ID for scrolling
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                }
                .background(Color.white) // Ensure background is white for the chat area
                .onChange(of: messages.count, initial: false) { // UPDATED: Added initial: false
                    // Automatically scroll to the last message when a new message is added
                    if let lastMessage = messages.last {
                        scrollViewProxy.scrollTo(lastMessage.id, anchor: .bottom)
                    }
                }
            }
            
            // Input Field
            VStack {
                Divider()
                HStack {
                    TextField("Type a Message...", text: $newMessage)
                        .padding(.vertical, 10)
                        .padding(.horizontal, 15)
                        .background(Color(.systemGray6))
                        .cornerRadius(25)
                        .overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(Color(.systemGray4), lineWidth: 0.5)
                        )
                        .focused($isInputActive) // Link to focus state
                        .onSubmit { // Call sendMessage when return is pressed
                            sendMessage()
                        }
                    
                    Button(action: {
                        // Simulate mic input for "hi"
                        newMessage = "hi" // Set the message to "hi"
                        sendMessage()     // Send it
                        isInputActive = false // Dismiss keyboard after "speaking"
                    }) {
                        Image(systemName: "mic.fill")
                            .font(.title2)
                            .foregroundColor(.gray)
                            .padding(.leading, 5)
                    }
                    
                    Button(action: {
                        // Action for image attachment
                    }) {
                        Image(systemName: "photo.fill.on.rectangle.fill")
                            .font(.title2)
                            .foregroundColor(.gray)
                            .padding(.leading, 5)
                    }
                }
                .padding(.horizontal)
                .padding(.vertical, 8)
            }
            .background(Color.white)
        }
    }
    
    // Message Sending Logic
    private func sendMessage() {
        // Ensure message is not empty or just whitespace
        guard !newMessage.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        
        // Add user's message to the chat
        messages.append(Message(text: newMessage, isUser: true, showProfilePic: true))
        
        // Process AI's response
        let lowercasedMessage = newMessage.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
        
        if lowercasedMessage == "hi" {
            messages.append(Message(text: "Hello user how are you doing today", isUser: false, showProfilePic: true))
        } else {
            // Generic AI response for other messages
            messages.append(Message(text: " I'm here to help!", isUser: false, showProfilePic: true))
        }
        
        // Clear the input field
        newMessage = ""
        isInputActive = false // Dismiss keyboard
    }
}

// MessageBubble Subview
struct MessageBubble: View {
    let message: Message
    
    var body: some View {
        HStack(alignment: .bottom) {
            if !message.isUser {
                // AI's profile picture
                if message.showProfilePic {
                    Image("Image Asset 3") 
                        .resizable()
                        .frame(width: 45, height: 60)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.gray, lineWidth: 0.5))
                } else {
                    
                    Spacer()
                        .frame(width: 30)
                }
            } else {
                Spacer() // Pushes user message to the right
            }
            
            Text(message.text)
                .padding(10)
                .background(message.isUser ? Color(red: 0.25, green: 0.45, blue: 0.85) : Color(.systemGray6)) // Darker blue for user
                .foregroundColor(message.isUser ? .white : .black)
                .cornerRadius(15)
                .font(.body)
                .fixedSize(horizontal: false, vertical: true) // Allows text to wrap
                .frame(maxWidth: UIScreen.main.bounds.width * 0.7, alignment: message.isUser ? .trailing : .leading) // Limit bubble width
            
            if message.isUser {
                // User's profile picture
                if message.showProfilePic {
                    Image("Image Asset 2") 
                        .resizable()
                        .frame(width: 30, height: 30)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.gray, lineWidth: 0.5))
                } else {
                    // Placeholder for alignment when no profile pic
                    Spacer()
                        .frame(width: 30)
                }
            } else {
                Spacer() // Pushes AI message to the left
            }
        }
        .padding(.horizontal, message.isUser ? 5 : 0) // Adjust padding for user bubbles
    }
}


// Preview Provider needed because of all of the text fields
struct AIAssistantView_Previews: PreviewProvider {
    static var previews: some View {
        AIAssistantView()
            .previewLayout(.sizeThatFits)
    }
}
