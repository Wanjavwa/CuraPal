import SwiftUI

// ThirdView: Login screen with NavigationStack
struct ThirdView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var path = NavigationPath()
    @State private var loginMessage = ""
    
    var body: some View {
        NavigationStack(path: $path) {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.cyan.opacity(0.9), Color.white]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                .ignoresSafeArea()
                
                VStack {
                    Spacer()
                    
                    Text("Welcome to CURAPAL")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(Color(red: 0.0, green: 0.19, blue: 0.55))
                        .padding(.bottom, 30)
                    
                    VStack(spacing: 20) {
                        // Username TextField
                        TextField("Username", text: $username)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(color: .gray.opacity(0.3), radius: 5)
                        
                        // Password SecureField
                        SecureField("Password", text: $password)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(color: .gray.opacity(0.3), radius: 5)
                        
                        // Login Button
                        Button(action: {
                            if username == "Shameeka" && password == "is the best professor" {
                                loginMessage = ""
                                path.append(username) // Navigates to FourthView
                            } else {
                                loginMessage = "Incorrect username or password."
                                username = ""
                                password = ""
                            }
                        }) {
                            Text("Log In")
                                .fontWeight(.semibold)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.green)
                                .foregroundColor(.white)
                                .cornerRadius(12)
                        }
                        
                        // Error Message
                        if !loginMessage.isEmpty {
                            Text(loginMessage)
                                .foregroundColor(.red)
                                .font(.subheadline)
                        }
                    }
                    .padding()
                    .background(Color.white.opacity(0.95))
                    .cornerRadius(20)
                    .shadow(radius: 10)
                    .padding(.horizontal, 30)
                    
                    Spacer()
                }
                .padding()
            }
            .navigationDestination(for: String.self) { username in
                FourthView(username: username)
            }
        }
    }
}


                
                
                
                
                
                
                
            
