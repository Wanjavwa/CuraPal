import SwiftUI


struct ContentView: View {
    @State private var showMainMenu = false
    @State private var fadeOutExplore = false
    
    var body: some View {
        NavigationView {
            ZStack {
                ZStack {
                    // Desgin element: creates the blue fading into whit background
                    LinearGradient(gradient: Gradient(colors: [Color.cyan.opacity(0.9), Color.white]),
                                   startPoint: .topLeading,
                                   endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                    
                    VStack(spacing: 30) {
                        // design element: creates the animation that transition into the getting started page
                        Image("Image Asset 1")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 200)
                            .opacity(showMainMenu ? 0.8 : 1.0)
                            .animation(.easeInOut(duration: 0.8), value: showMainMenu)
                        
                        
                        if !showMainMenu {
                            // if and elses components if yes or true fadeoutexplore will be set to true
                            Button(action: {
                                withAnimation(.easeInOut(duration: 0.8)) {
                                    fadeOutExplore = true
                                }
                                // Delay for animation before showing main menu
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                                    showMainMenu = true
                                }
                            }) {
                                Text("Explore")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 40)
                                    .padding(.vertical, 15)
                                    .background(Color.blue)
                                    .cornerRadius(30)
                            }
                            .opacity(fadeOutExplore ? 0 : 1)
                            .animation(.easeInOut(duration: 0.8), value: fadeOutExplore)
                        }
                        
                        if showMainMenu {
                            Text("Because care never gets old")
                                .font(.title2)
                                .fontWeight(.medium)
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                                .transition(.opacity)
                                .animation(.easeInOut(duration: 0.5), value: showMainMenu)
                            
                            VStack(spacing: 16) {
                                NavigationLink(destination: SecondView()) {
                                    Text("Getting Started")
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.green)
                                        .foregroundColor(.white)
                                        .font(.headline)
                                        .cornerRadius(12)
                                        .shadow(radius: 4)
                                }// different design elements above for the getting started button
                                
                                NavigationLink(destination: ThirdView()) {
                                    Text("Sign In")
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(Color.blue)
                                        .foregroundColor(.white)
                                        .font(.headline)
                                        .cornerRadius(12)
                                        .shadow(radius: 4)
                                }
                            }
                        }
                    }
                }
            }
        }
    
    }
    
}


