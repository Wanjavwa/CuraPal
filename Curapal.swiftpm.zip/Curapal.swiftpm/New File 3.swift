import SwiftUI

struct Medication: Identifiable {
    let id = UUID()
    var name: String
    var dosage: String
    var time: String
    var isTaken: Bool
}

struct Caregiver {
    var name: String
    var relationship: String
}

struct MedicationView: View {
    @State private var todayMedications: [Medication] = [
        Medication(name: "Theta Blocker", dosage: "10 mg", time: "8:00 AM", isTaken: true),
        Medication(name: "Zeta Tablet", dosage: "20 mg", time: "1:00 PM", isTaken: false),
        Medication(name: "Omicron Pill", dosage: "5 mg", time: "6:00 PM", isTaken: true)
    ]
    
    @State private var notifyCaregiver: Bool = false
    
    // New Medication Input Fields
    @State private var newMedName: String = ""
    @State private var newMedDosage: String = ""
    @State private var newMedTime: String = ""
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                
                
                HStack {
                    Image(systemName: "chevron.left")
                        .font(.headline)
                        .padding(.leading)
                    Spacer()
                }
                
                Text("Today's Medications")
                    .font(.title2)
                    .bold()
                    .padding(.horizontal)
                
                
                ForEach($todayMedications) { $med in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(med.name)
                                .font(.headline)
                            Text("\(med.dosage) at \(med.time)")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        Spacer()
                        Toggle("", isOn: $med.isTaken)
                            .labelsHidden()
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                
                
                Toggle("Notify caregiver if dose missed", isOn: $notifyCaregiver)
                    .padding(.horizontal)
                
                Divider().padding(.vertical)
                
                
                Text("Add New Medication")
                    .font(.headline)
                    .padding(.horizontal)
                
                VStack(spacing: 12) {
                    TextField("Medication Name", text: $newMedName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Dosage (e.g. 10 mg)", text: $newMedDosage)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Time (e.g. 8:00 AM)", text: $newMedTime)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Button(action: {
                        if !newMedName.isEmpty && !newMedDosage.isEmpty && !newMedTime.isEmpty {
                            let newMed = Medication(name: newMedName, dosage: newMedDosage, time: newMedTime, isTaken: false)
                            todayMedications.append(newMed)
                            newMedName = ""
                            newMedDosage = ""
                            newMedTime = ""
                        }
                    }) {
                        Text("Add Medication")
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(10)
                    }
                }
                .padding(.horizontal)
                
                Spacer(minLength: 50)
            }
        }
        .navigationTitle("Medication")
    }
}
