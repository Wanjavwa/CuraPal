import SwiftUI


struct CaregiverContact: Identifiable {
    let id = UUID()
    var name: String
    var role: String
    var isOn: Bool
}


struct CircleOfCareView: View {
    @State private var contacts: [CaregiverContact] = [
        CaregiverContact(name: "Sarah", role: "Daughter", isOn: true),
        CaregiverContact(name: "Michael", role: "Friend", isOn: false),
        CaregiverContact(name: "Patricia", role: "Nurse", isOn: true)
    ]
    
    @State private var newName: String = ""
    @State private var newRole: String = ""
    
    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                
                HStack {
                    Spacer()
                    Text("Circle of Care")
                        .font(.headline)
                        .bold()
                    Spacer()
                }
                .padding()
                
               
                ForEach($contacts) { $contact in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(contact.name)
                                .font(.headline)
                            Text(contact.role)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        Spacer()
                        Toggle("", isOn: $contact.isOn)
                            .labelsHidden()
                    }
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                
                Divider().padding(.horizontal)
                
                
                VStack(alignment: .leading, spacing: 12) {
                    Text("Add New Contact")
                        .font(.headline)
                    
                    TextField("Name", text: $newName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Role", text: $newRole)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Button(action: {
                        guard !newName.isEmpty && !newRole.isEmpty else { return }
                        let newContact = CaregiverContact(name: newName, role: newRole, isOn: true)
                        contacts.append(newContact)
                        newName = ""
                        newRole = ""
                    }) {
                        Text("Add Contact")
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                }
                .padding()
                
                Spacer()
            }
            .navigationBarHidden(true)
        }
    }
}

