import SwiftUI

struct FitnessView: View {
    @State private var isStretchingCompleted: Bool = false
    @State private var isMentalWellnessCompleted: Bool = false
    @State private var notifyCaregiver: Bool = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                
                HStack {
                    Image(systemName: "chevron.left")
                        .font(.headline)
                        .padding(.leading)
                    Spacer()
                    Text("Fitness & Wellness")
                        .font(.headline)
                        .bold()
                    Spacer()
                    Image(systemName: "chevron.left")
                        .font(.headline)
                        .opacity(0)
                        .padding(.trailing)
                }
                .padding(.vertical, 10)
                .background(Color.white)
                .cornerRadius(10)
                .padding([.leading, .trailing, .top])
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 15) {
                        
                        
                        Text("Today's Fitness Tasks")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                            .padding(.horizontal)
                            .padding(.top, 10)
                        
                        
                        HStack(spacing: 15) {
                            Image(systemName: "figure.arms.open")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 40, height: 40)
                                .foregroundColor(.blue)
                            VStack(alignment: .leading) {
                                Text("Stretching Exercises")
                                    .font(.headline)
                                Text("50 min / 30 min")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            Spacer()
                            Toggle("", isOn: $isStretchingCompleted)
                                .labelsHidden()
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .padding(.horizontal)
                        
                       
                        HStack(spacing: 15) {
                            Image(systemName: "brain.head.profile")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 40, height: 40)
                                .foregroundColor(.purple)
                            VStack(alignment: .leading) {
                                Text("Mental Wellness")
                                    .font(.headline)
                                Text("Meditation / Breathing")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            Spacer()
                            Toggle("", isOn: $isMentalWellnessCompleted)
                                .labelsHidden()
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .padding(.horizontal)
                        
                        // Notify Caregiver Button
                        if isStretchingCompleted || isMentalWellnessCompleted {
                            Button(action: {
                                notifyCaregiver = true
                            }) {
                                Text("Notify Caregiver")
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.green)
                                    .cornerRadius(10)
                            }
                            .padding(.horizontal)
                        }
                    }
                    .padding(.bottom, 20)
                }
                .padding(.top, 5)
                
                Spacer()
                
                
                HStack {
                    Spacer()
                    Image(systemName: "house.fill")
                        .font(.title2)
                        .foregroundColor(.blue)
                    Spacer()
                    Image(systemName: "checkmark.circle.fill")
                        .font(.title2)
                        .foregroundColor(.gray)
                    Spacer()
                    Image(systemName: "person.fill")
                        .font(.title2)
                        .foregroundColor(.gray)
                    Spacer()
                }
                .padding(.vertical, 10)
                .background(Color.white)
                .cornerRadius(10)
                .padding([.leading, .trailing, .bottom])
            }
            .background(Color(.systemGray6))
            .navigationBarHidden(true)
        }
    }
}
