import SwiftUI

struct FourthView: View {
    let username: String
    
    var body: some View {
        NavigationView {
            ScrollView {
                ZStack(alignment: .topLeading) {
                    LinearGradient(
                        gradient: Gradient(colors: [Color.cyan.opacity(0.9), Color.white]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    .ignoresSafeArea()
                    
                    VStack(alignment: .leading, spacing: 20) {
                        
                        // Greeting Header
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Good Morning,")
                                    .font(.title2)
                                    .foregroundColor(.black)
                                
                                HStack(spacing: 8) { // Places the username and AI button side-by-side
                                    Text(username)
                                        .font(.largeTitle)
                                        .fontWeight(.bold)
                                        .foregroundColor(.blue)
                                    
                                    // AI Assistant Button
                                    NavigationLink(destination: AIAssistantView()) { 
                                        
                                        Image(systemName: "smiley.fill") 
                                            .font(.headline)
                                            .foregroundColor(.white)
                                            .padding(8) // Size of the button
                                            .background(Color.blue.opacity(0.9))
                                            .clipShape(Circle()) 
                                            .shadow(radius: 2) 
                                    }
                                    .buttonStyle(PlainButtonStyle())
                                }
                            
                            }
                            
                            Spacer()
                            
                            // Profile Image Navigation
                            NavigationLink(destination: ProfileView()) {
                                // when the image is selected the navigation is triggered
                                Image("Image Asset 2")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 120, height: 120)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.white, lineWidth: 2))
                                    .shadow(radius: 5)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                        .padding(.horizontal)
                        .padding(.top, 10)
                        
                    //sleep and water cards
                        HStack(spacing: 16) {
                            NavigationLink(destination: SleepView()) {
                                SleepCard()
                            }
                            NavigationLink(destination: WaterView()) {
                                WaterCard()
                            }
                        }
                        .padding(.horizontal)
                        
                        // MARK: - Status Cards
                        VStack(spacing: 16) {
                            StatusCard(title: "2 of 4 medications taken", icon: "pill.fill")
                            StatusCard(title: "58 BPM Vitals are okay!", icon: "heart.fill")
                            StatusCard(title: "1 of 4 goals achieved", icon: "compass.rose.fill")
                        }
                        
                        // page navigations
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                            NavigationLink(destination: MedicationView()) {
                                HomeButton(title: "Medication\nTracker", icon: "cross.case.fill")
                            }
                            NavigationLink(destination: FitnessView()) {
                                HomeButton(title: "Wellness\nPlan", icon: "figure.walk")
                            }
                            NavigationLink(destination: CircleOfCareView()) {
                                HomeButton(title: "Circle of\nCare", icon: "person.3.fill")
                            }
                            NavigationLink(destination: PharmacyFinderView()) {
                                HomeButton(title: "Find\nMedication", icon: "magnifyingglass")
                            }
                        }
                        .padding(.horizontal)
                    }
                    .padding(.vertical)
                }
            }
        }
    }
}

// SleepCard
struct SleepCard: View {
    @State private var barHeights: [CGFloat] = []
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Image(systemName: "moon.fill")
                    .font(.title2)
                    .foregroundColor(.purple)
                Text("Sleep")
                    .font(.headline)
                    .foregroundColor(.black)
                Spacer()
            }
            .padding(.bottom, 5)
            
            VStack(alignment: .leading) {
                HStack(alignment: .bottom, spacing: 2) {
                    ForEach(0..<barHeights.count, id: \.self) { index in
                        Rectangle()
                            .fill(Color.purple.opacity(0.6))
                            .frame(width: 8, height: barHeights[index])
                            .cornerRadius(2)
                    }
                }
                
                Text("8h 15m")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 120)
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .padding(.horizontal, 5)
        .onAppear {
            barHeights = (0..<7).map { _ in CGFloat.random(in: 30...80) }
        }
    }
}

// WaterCard
struct WaterCard: View {
    let currentCups: Int = 2
    let totalCups: Int = 8
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Image(systemName: "drop.fill")
                    .font(.title2)
                    .foregroundColor(.blue)
                Text("Water")
                    .font(.headline)
                    .foregroundColor(.black)
                Spacer()
            }
            .padding(.bottom, 5)
            
            VStack(alignment: .leading) {
                Text("\(currentCups)/\(totalCups) Cups")
                    .font(.title3)
                    .fontWeight(.bold)
                    .foregroundColor(.blue)
                
                GeometryReader { geometry in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.gray.opacity(0.3))
                            .frame(height: 20)
                        
                        Capsule()
                            .fill(Color.blue)
                            .frame(width: geometry.size.width * CGFloat(currentCups) / CGFloat(totalCups), height: 20)
                    }
                }
                .frame(height: 20)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 120)
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .padding(.horizontal, 5)
    }
}

//  StatusCards
struct StatusCard: View {
    let title: String
    let icon: String
    
    var body: some View {
        VStack {
            Image(systemName: icon)
                .font(.title)
                .foregroundColor(.blue)
            
            Text(title)
                .font(.subheadline)
                .multilineTextAlignment(.center)
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 100)
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .padding(.horizontal, 5)
    }
}

// Navigation Buttons
struct HomeButton: View {
    let title: String
    let icon: String
    
    var body: some View {
        VStack {
            Image(systemName: icon)
                .font(.title)
                .foregroundColor(.white)
            Text(title)
                .foregroundColor(.white)
                .font(.subheadline)
                .multilineTextAlignment(.center)
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 100)
        .background(Color.blue)
        .cornerRadius(12)
    }
}


struct SleepView: View { var body: some View { Text("Sleep Tracking Details") } }
struct WaterView: View { var body: some View { Text("Water Intake Details") } }
import SwiftUI
struct ProfileView: View {
    var body: some View {
        
        NavigationView {
            ZStack {
                // Background gradient
                LinearGradient(
                    gradient: Gradient(colors: [Color.cyan.opacity(0.9), Color.white]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                List {
                    // Profile Header Section
                    VStack(alignment: .leading, spacing: 16) {
                        HStack(alignment: .center, spacing: 16) {
                            Image("Image Asset 2")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 100, height: 100)
                                .clipShape(Circle())
                                .overlay(Circle().stroke(Color.white, lineWidth: 2))
                                .shadow(radius: 5)
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Shameeka")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.black)
                                Text("80 year old grandma")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding(.top, 10)
                    }
                    .listRowBackground(Color.clear)
                    
                    // Profile Options Section
                    Section {
                        ProfileRow(icon: "person.fill", text: "Personal Info")
                        ProfileRow(icon: "map.fill", text: "Addresses")
                        ProfileRow(icon: "pills.fill", text: "Medications")
                        ProfileRow(icon: "heart.fill", text: "Your people")
                        ProfileRow(icon: "bell.fill", text: "Reminders")
                        ProfileRow(icon: "fork.knife", text: "Dietary & Allergies")
                    }
                    
                    // Settings and Logout Section
                    Section {
                        ProfileRow(icon: "gearshape.fill", text: "Settings")
                        ProfileRow(icon: "arrow.right.square.fill", text: "Log Out", textColor: .red)
                    }
                }
                .listStyle(InsetGroupedListStyle())
                .scrollContentBackground(.hidden)
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("Profile")
                        .font(.headline)
                        .foregroundColor(.black)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack {
                        Button(action: {
                            // Settings Action
                        }) {
                            Image(systemName: "gearshape")
                                .foregroundColor(.blue)
                        }
                        Button(action: {
                            // More Options Action
                        }) {
                            Image(systemName: "ellipsis")
                                .foregroundColor(.blue)
                        }
                    }
                }
            }
            .toolbarBackground(
                LinearGradient(gradient: Gradient(colors: [Color.cyan.opacity(0.9), Color.white]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing),
                for: .navigationBar
            )
            .toolbarBackground(.visible, for: .navigationBar)
        }
    }
}

// ProfileRow

struct ProfileRow: View {
    let icon: String
    let text: String
    var textColor: Color = .black
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(.blue)
                .frame(width: 25)
            
            Text(text)
                .foregroundColor(textColor)
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .foregroundColor(.gray)
                .font(.caption)
        }
        .padding(.vertical, 8)
        .listRowBackground(Color.clear)
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}









//Preview Provider
struct FourthView_Previews: PreviewProvider {
    static var previews: some View {
        FourthView(username: "Emma") // Provide a username for the preview
    }
}
